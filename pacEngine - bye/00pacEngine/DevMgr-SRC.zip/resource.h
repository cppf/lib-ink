//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DevMgr.rc
//
#define IDD_DIALOG1                     101
#define IDI_MYCOMP                      102
#define IDB_MYCOMP                      103
#define IDD_DIALOG2                     104
#define IDC_TREE1                       1000
#define IDC_ADDBTN                      1001
#define IDC_DELBTN                      1002
#define IDC_REFBTN                      1003
#define IDC_RADIO1                      1004
#define IDC_RADIO2                      1005
#define IDC_LIST1                       1006
#define IDC_EXIT                        1007
#define IDC_INSTALLBTN                  1008
#define IDC_COPYPATHBTN                 1008
#define IDC_IEXIT                       1009
#define IDC_DISABLEBTN                  1009
#define IDC_RESETBTN                    1010
#define IDC_OPENINFBTN                  1011
#define IDC_INFLBL                      1012
#define IDC_PARAMOPT1                   1013
#define IDC_PARAMOPT2                   1014
#define IDC_PARAMOPT3                   1015
#define IDC_PARAMOPT4                   1016
#define IDC_PARAMOPT5                   1017
#define IDC_PARAMOPT6                   1018
#define IDC_PARAMOPT7                   1019
#define IDC_PARAMOPT8                   1020
#define IDC_PARAMOPT9                   1021
#define IDC_LIST2                       1022
#define IDC_ENABLEDRVBTN                1022
#define IDC_MOREINFOBTN                 1023
#define IDC_DRVNAMETXT                  1025
#define IDC_CHECK1                      1026

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1027
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
